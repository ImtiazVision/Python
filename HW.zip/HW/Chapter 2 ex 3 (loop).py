# Imtiaz Ahmed
# 3.25.19
# HW Project
# Ch2ex3
def main():
    for i in range(5):
        celsius = eval(input("Enter Celsius temperature: "))
        fahrenheit = 9.0 / 5.0 * celsius + 32
        print("The temperature is", fahrenheit, "degrees Fahrenheit.")
        print()

main()
