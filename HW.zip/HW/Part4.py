def main( ):
    print("This program converts currency  Argentine peso from to USD and  Euro")
    peso = eval(input("Enter Argentine peso:"))
    USD = peso*.024
    Euro = peso*.021
    print("USD = $", USD,"Euro = $", Euro)

main()
