# Imtiaz Ahmed
# 3.25.19
# HW Project
# Ch2ex9
def main():
    print("This program converts kilometers to miles.")
    print()
    
    kiloms = eval(input("Enter the distance in kilometers: "))
    miles = kiloms * 0.62
    print("The distance is", miles, "miles.")

main()
