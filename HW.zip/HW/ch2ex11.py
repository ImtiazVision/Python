# Imtiaz Ahmed
# 3.25.19
# HW Project
# Ch 2 Ex 11
def main():
    print("Welcome to the Interactive Python Calculator")
    for i in range(100):
        result = eval(input(">>>>>"))
        print(result)
        

main()
