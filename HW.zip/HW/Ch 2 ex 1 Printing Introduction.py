# Imtiaz Ahmed
# 3.25.19
# HW Project
# Q #1 Ch2ex1
def main():
    print("This program converts Celsius temperatures to Fahrenheit.")
    print()
    celsius = eval(input("Please enter Celsius temperature: "))
    fahrenheit = 9.0 / 5.0 * celsius + 32
    print("The temperature is", fahrenheit, "degrees Fahrenheit.")

main()

